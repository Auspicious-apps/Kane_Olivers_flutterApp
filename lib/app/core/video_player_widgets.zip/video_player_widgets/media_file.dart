class MediaFile {
  int? id;
  String? localPath;
  String? networkPath;

  MediaFile({this.id = 1, this.localPath, this.networkPath});
}
